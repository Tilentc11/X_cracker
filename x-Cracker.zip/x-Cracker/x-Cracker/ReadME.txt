1. Open the installer and roblox.com webpage and put in the targets id
2. Put in your webhook
3. wait for installer to finish
4. open cracker and wait 
5. When finnished it will send you a discord massage